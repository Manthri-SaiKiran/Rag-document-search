import pinecone
from langchain.vectorstores import Pinecone
from app.config import PINECONE_API_KEY, PINECONE_ENV, INDEX_NAME

def init_pinecone(embeddings):
    pinecone.init(api_key=PINECONE_API_KEY, environment=PINECONE_ENV)
    return Pinecone.from_existing_index(INDEX_NAME, embeddings)
