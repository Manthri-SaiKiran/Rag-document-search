PROMPT_TEMPLATE = """
You are a helpful assistant.
Answer ONLY from the provided context.
If the answer is not in the context, say "I don't know."

Context:
{context}

Question:
{question}

Answer:
"""
