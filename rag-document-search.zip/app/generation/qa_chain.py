from langchain.chains import RetrievalQA
from langchain.chat_models import ChatOpenAI
from app.generation.prompt import PROMPT_TEMPLATE

def build_qa_chain(retriever):
    llm = ChatOpenAI(temperature=0)

    return RetrievalQA.from_chain_type(
        llm=llm,
        retriever=retriever,
        chain_type_kwargs={"prompt": PROMPT_TEMPLATE}
    )
