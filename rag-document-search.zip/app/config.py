import os
from dotenv import load_dotenv
load_dotenv()

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
PINECONE_API_KEY = os.getenv("PINECONE_API_KEY")
PINECONE_ENV = os.getenv("PINECONE_ENV")

INDEX_NAME = "rag-doc-search"
TOP_K = 5
CHUNK_SIZE = 500
CHUNK_OVERLAP = 50
