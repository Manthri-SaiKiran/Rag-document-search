import streamlit as st
from scripts.query import ask

st.title("Chat with Your Data")

query = st.text_input("Ask something")

if query:
    response = ask(query)
    st.write(response)
