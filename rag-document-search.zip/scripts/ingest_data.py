from app.ingestion.loader import load_pdf
from app.ingestion.chunking import split_documents
from app.ingestion.embeddings import get_embeddings
from app.retrieval.vector_store import init_pinecone

def run_ingestion(file_path):
    docs = load_pdf(file_path)
    chunks = split_documents(docs)
    embeddings = get_embeddings()
    vector_store = init_pinecone(embeddings)
    vector_store.add_documents(chunks)

if __name__ == "__main__":
    run_ingestion("data/raw/sample.pdf")
