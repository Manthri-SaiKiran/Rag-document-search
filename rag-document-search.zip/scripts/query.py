from app.ingestion.embeddings import get_embeddings
from app.retrieval.vector_store import init_pinecone
from app.retrieval.retriever import get_retriever
from app.generation.qa_chain import build_qa_chain

def ask(query):
    embeddings = get_embeddings()
    vector_store = init_pinecone(embeddings)
    retriever = get_retriever(vector_store)
    qa_chain = build_qa_chain(retriever)
    response = qa_chain.run(query)
    print(response)

if __name__ == "__main__":
    ask("What is this document about?")
